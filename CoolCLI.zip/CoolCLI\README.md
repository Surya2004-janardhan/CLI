# CoolCLI

A full-featured, colorful Command Line Interface (CLI) built in C for Windows.

## Features

- **100+ Commands** across multiple categories:
  - System: sysinfo, dir, mem, cls, cpu, os
  - Math: add, sub, mul, div, prime, fibonacci, factorial, gcd, lcm, sort
  - String/Text: upper, lower, reverse, count, search, replace, palindrome
  - Fun: joke, riddle, quiz, timer, beep, banner, colors
  - Network: ping, ip, dns, netstat
  - Utility: calc, history, alias, help, exit, about, credits
- Colorful UI using Windows Console API
- ASCII art banner on startup
- Command history logging
- Modular design for easy extension
- Error handling for unknown commands

## Compilation

Ensure MinGW GCC is installed.

Run `make` to compile:

```bash
make
```

This will generate `coolcli.exe`.

## Usage

Run the executable:

```bash
./coolcli.exe
```

Type commands at the prompt. Type `help` for a list of commands.

## Example

```
CoolCLI> help
CoolCLI Help - Available Commands:

System Commands:
  sysinfo, dir, mem, cls, cpu, os

Math Commands:
  add, sub, mul, div, prime, fibonacci, factorial, gcd, lcm, sort

...

CoolCLI> add 5 3
5.00 + 3.00 = 8.00
```

## Screenshots

_(Imagine colorful output here)_

## Project Structure

- `main.c`: Entry point and command loop
- `commands.c`: Command implementations
- `commands.h`: Command declarations
- `utils.c`: Utility functions (colors, parsing)
- `utils.h`: Utility declarations
- `Makefile`: Build script
- `README.md`: This file

## Contributing

Add new commands by:

1. Declaring in `commands.h`
2. Implementing in `commands.c`
3. Adding to the `commands` array
